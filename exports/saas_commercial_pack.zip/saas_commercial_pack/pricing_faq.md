## FAQ de precios

### ¿Hay prueba gratuita?
Sí, 14 días con todas las funciones de Pro.

### ¿Cómo se cuentan los proyectos?
Son proyectos activos en el mes (con hitos abiertos). Los archivados no cuentan.

### ¿Puedo cambiar de plan en cualquier momento?
Sí, upgrades/downgrades prorrateados al instante.

### ¿Cobran por usuario extra?
Desde Pro, USD 5/usuario/mes adicional.

### ¿Qué pasa si excedo los proyectos?
Puedes comprar proyectos extra (USD 1–2/proyecto) o subir de plan.

### ¿Ofrecen descuento anual?
Sí, 15–20% (equivalente a 2 meses gratis).

### ¿Qué métodos de pago aceptan?
Tarjeta, transferencia y opciones locales vía Stripe donde aplique.
