## Página de precios — ProSocial SaaS por Proyecto

### Titular
Crece con un CRM por proyecto listo para cerrar ventas

### Subtítulo
Capta, cotiza, compara y cobra — todo en un solo lugar. Empieza en minutos.

### Planes y precios
- Básico — USD 19–29/mes (2 usuarios, 5 proyectos/mes, 5 GB). Ideal para equipos pequeños.
- Pro — USD 39–59/mes (5 usuarios, 20 proyectos/mes, 25 GB). Incluye ManyChat disponibilidad, recordatorios y costeo.
- Premium — USD 79–129/mes (15 usuarios, 60 proyectos/mes, 100 GB). API/Webhooks, dominios, soporte prioritario.

Descuento anual 15–20%. Precios localizados para LATAM.

### CTA
- Comienza gratis 14 días
- Habla con ventas

### Diferenciadores
- Funnel completo: landing + WhatsApp + comparador + Stripe.
- Costos y nómina por proyecto para rentabilidad real.
- Plantillas por vertical y workflows listos.

### Preguntas rápidas
- ¿Puedo agregar usuarios extra? Sí, USD 5/usuario/mes (desde Pro).
- ¿Y proyectos extra? USD 1–2 por proyecto activo adicional.
